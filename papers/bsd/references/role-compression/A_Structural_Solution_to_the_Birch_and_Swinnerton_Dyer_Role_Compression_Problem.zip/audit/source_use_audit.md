# Source-Use Audit

| Source class | Supplies | Does not supply |
|---|---|---|
| Classical BSD sources | arithmetic vocabulary, standard BSD formula, known proof-program landscape | AASC solution criterion or structural theorem |
| Gross-Zagier/Kolyvagin and rank 0/1 literature | local bridge-completion examples and bridge pressure | universal BSD for all curves |
| Selmer and Tate-Shafarevich literature | descent and obstruction vocabulary | unbridged Mordell-Weil rank readout |
| Numerical BSD sources | finite evidence and computational context | universal bridge completion by approximation alone |
| AASC structural sources | report-status, admissibility, no-repair, no-surrogate, and role-occupation constraints | arithmetic construction of rational points or finiteness of Sha |
| Corpus matrix scan | generic support counts and absence of prior BSD-local corpus arc | prior BSD-specific theorem content |
