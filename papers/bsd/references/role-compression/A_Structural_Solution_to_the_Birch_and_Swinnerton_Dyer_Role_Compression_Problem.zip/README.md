# AASC BSD Publication-Final Grok-Polished Project

This package contains the final polished LaTeX project for:

**A Structural Solution to the Birch and Swinnerton-Dyer Role-Compression Problem: Analytic Rank, Mordell--Weil Rank, and Bridge Discipline under AASC/UEAP**

## Build

Run:

```bash
bash build.sh
```

or:

```bash
make
```

The build produces `AASC_BSD_GrokPolished_Manuscript.pdf`.

## Final polish pass

This pass added:

- a reader-guidance box after the abstract/keywords;
- an additional plain-language sentence linking the compressed BSD equality to the three-layer bridge;
- a compact bridge-test summary table at the end of Section 11;
- an expanded structural formalization map with bridge-slot, bridge-admissibility, bridge-completion, route-normal-form, and no-ninth-route predicates;
- a presentation sweep for draft language and vulnerable overclaim phrasing.

The manuscript remains scoped to the AASC structural theorem

`RoleSolution_AASC(BSD-RoleCompression)`

and does not claim a classical proof of the Birch and Swinnerton-Dyer Conjecture.
