#!/usr/bin/env bash
set -euo pipefail
cp src/AASC_BSD_GrokPolished_Manuscript.tex _build_main.tex
pdflatex -interaction=nonstopmode -halt-on-error _build_main.tex
pdflatex -interaction=nonstopmode -halt-on-error _build_main.tex
cp _build_main.pdf AASC_BSD_GrokPolished_Manuscript.pdf
